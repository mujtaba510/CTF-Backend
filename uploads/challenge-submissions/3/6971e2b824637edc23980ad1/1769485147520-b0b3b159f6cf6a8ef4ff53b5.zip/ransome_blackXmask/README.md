# Windows Ransomware (blackXmask)

A demonstration of ransomware behavior on Windows systems. This tool encrypts/deletes files on specified drives and provides recovery instructions.

## Features
- Encrypts/decrypts files with custom extensions
- Supports multiple disk drives
- Generates unique encryption keys
- Provides recovery instructions

## Requirements
- Python 3.x
- Windows OS (tested on Windows 10)
- Required packages: cryptography, pywin32, flask

## Installation
```bash
pip install cryptography pywin32 flask
```

## Usage
1. Run the application:
```bash
python app.py
```
2. Open browser to http://localhost:8080
3. Click "Encrypt All Files" or "Decrypt All Files"

## File Extensions
By default, the following file types are targeted:
- .txt
- .png

Modify the EXTENSIONS array in ransomware_windows.py to include other extensions.

## Security Considerations
⚠️ WARNING: This is a demo only - do not use on real systems!
- The tool creates backups before encryption
- Uses secure encryption algorithms
- Does not delete files by default (can be modified in code)

## Recovery Process
After encryption:
1. Download the encryption key from the main page
2. Use the provided recovery script to restore files
3. Original files will be restored with their original names

## Troubleshooting
- If encryption fails, check permissions on target directories
- For large drives, encryption may take several minutes
- Ensure sufficient disk space for temporary files

## License
MIT License - see LICENSE file for details

## Disclaimer
This software is provided as-is without warranty. Use at your own risk.