MISSION 001 SOLUTION: INVOICE LURE ANALYSIS

[1] SOCIAL ENGINEERING STRATEGY
- Scenario: Targeted attack on Finance Dept.
- Lure: "Overdue Invoice" triggering urgency/fear.
- Context: Email claims service suspension if not opened.

[2] TECHNICAL EXPLANATION
- Binder: I conceptually bound the payload to a legitimate PDF.
- Icon Spoofing: In a real scenario, the icon would be changed to Adobe Acrobat.
- Extension: Used "Double Extension" (Invoice.pdf.exe). Windows hides the .exe, so users see only .pdf.

[3] ATTACHED FILE
- The included file "Invoice_INV-2024-001.pdf.exe" is a Proof of Concept.
- It demonstrates the naming convention and icon spoofing.
- NO active malware is included for safety.
