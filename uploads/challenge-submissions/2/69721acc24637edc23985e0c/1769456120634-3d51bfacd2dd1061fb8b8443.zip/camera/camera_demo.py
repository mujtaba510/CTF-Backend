from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import time
import os

# =========================
# CONFIG
# =========================

HEADLESS = True   # 🔁 Set to True for invisible mode, False to show browser

# =========================
# Chrome options
# =========================

options = Options()

# 🔴 Auto‑allow camera & mic (no permission prompt)
options.add_argument("--use-fake-ui-for-media-stream")

# Optional: fake camera feed (recommended for headless)
# options.add_argument("--use-fake-device-for-media-stream")

# Optional UI tweaks
options.add_argument("--disable-infobars")
options.add_argument("--start-maximized")

# 👻 Headless / invisible mode
if HEADLESS:
    options.add_argument("--headless=new")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")

# =========================
# Open local HTML file
# =========================

html_path = "file:///" + os.path.abspath("camera.html")

driver = webdriver.Chrome(options=options)
driver.get(html_path)

mode = "HEADLESS (invisible)" if HEADLESS else "VISIBLE"
print(f"Chrome opened in {mode} mode with camera auto-allowed")

# Keep browser open for demo
time.sleep(60)

driver.quit()
