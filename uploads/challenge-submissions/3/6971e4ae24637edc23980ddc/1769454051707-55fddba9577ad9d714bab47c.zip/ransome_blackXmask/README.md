# Windows Ransomware (blackXmask)

This is a demonstration of ransomware behavior for educational purposes only. It encrypts and decrypts files across all Windows disks.

## Features

- Encrypts all files on all Windows disks
- Adds malware signature to encrypted files
- Provides key download for decryption
- Cross-platform compatible (Windows/Linux/macOS)
- Clean web interface for operation control

## Requirements

- Python 3.x
- Windows OS (requires pywin32 package)
- Python packages:
  - cryptography
  - flask
  - pywin32 (Windows only)

## Installation

1. Install Python 3.x from python.org
2. Install required packages:
   ```
   pip install cryptography flask pywin32
   ```

## Usage

1. Run the ransomware:
   ```
   python ransomware_windows.py
   ```

2. Open browser and visit:
   ```
   http://localhost:8080
   ```

3. Click "Encrypt All Files" to encrypt files
4. Download the key when prompted
5. Use the key to decrypt files later

## Recovery

To decrypt files:
1. Download the `ransom_key.key` file
2. Run this Python script:
   ```python
   from cryptography.fernet import Fernet
   import os

   with open('ransom_key.key', 'rb') as key_file:
       key = key_file.read()
   fernet = Fernet(key)

   for dirpath, _, filenames in os.walk('/'):
       for filename in filenames:
           if filename.endswith('.encrypted'):
               filepath = os.path.join(dirpath, filename)
               with open(filepath, 'rb') as f:
                   encrypted_contents = f.read()
               decrypted = fernet.decrypt(encrypted_contents)
               
               # Remove malware signature
               start = decrypted.find(b"MALWARE_SIGNATURE") + len(b"MALWARE_SIGNATURE")
               end = decrypted.find(b"END_MALWARE_SIGNATURE")
               if start > len(b"MALWARE_SIGNATURE") and end > start:
                   clean_content = decrypted[start:end]
               else:
                   clean_content = decrypted
                   
               # Restore original file
               original_name = filepath.replace('.encrypted', '')
               with open(original_name, 'wb') as f:
                   f.write(clean_content)
               os.remove(filepath)
   ```

## Security Notes

- Never run this on real systems!
- This is for educational purposes only
- The key is stored in the current directory
- Encrypted files have `.encrypted` extension
- Original files are overwritten during encryption

## Disclaimer

This code is for educational purposes only. The author is not responsible for any damage caused by this code. Always test on non-critical systems first.

## License

MIT License - see LICENSE.txt for details.