MISSION 003 SOLUTION: RANSOMWARE BEHAVIOR ANALYSIS

[1] LOGIC EXPLANATION
- Discovery: The script uses 'os.walk()' to recursively map the directory structure, mimicking the "Seek" phase of ransomware.
- Targeting: It filters for specific extensions (.txt) to maximize impact on user data while ignoring system files (to keep the OS running).
- Action: It performs an in-place rename operation to simulate encryption. In a real scenario, this would be replaced with an AES-256 write stream.

[2] SAFETY MEASURES
- The attached script is confined to the current working directory.
- No cryptographic destruction is performed, only extension appending.
